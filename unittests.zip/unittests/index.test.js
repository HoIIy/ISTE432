const ind = require('./index');

test('map is created and defined', () => {
	expect(ind.initMap).toBeDefined();
});